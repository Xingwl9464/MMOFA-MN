load('SYM_PART_rotated.mat');

plot(PF(:, 1), PF(:, 2), 'k.');
xlabel('1^{st} Objective');
ylabel('2^{nd} Objective');