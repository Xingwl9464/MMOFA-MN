load('MMF14_a.mat');

scatter3(PS(:, 1), PS(:, 2),PS(:,3), 'k.');
xlabel('x1');
ylabel('x2');
zlabel('x3');