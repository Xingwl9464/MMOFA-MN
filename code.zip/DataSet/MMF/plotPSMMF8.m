load('MMF8.mat');

plot(PS(:,1),PS(:,2),'k.');
xlabel('x1');
ylabel('x2');