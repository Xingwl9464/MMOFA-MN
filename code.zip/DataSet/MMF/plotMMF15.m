load('MMF15.mat');

scatter3(PF(:, 1), PF(:, 2),PF(:,3),'k.');

xlabel('1^{st} Objective');
ylabel('2^{nd} Objective');
zlabel('3^{nd} Objective');